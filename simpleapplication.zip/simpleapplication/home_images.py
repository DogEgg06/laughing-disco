class home_images():
    image_id = 0
    def __init__(self, image_id,):
        home_images.__image_id = image_id


    def get_image_id(self):
        return self.__image_id

    def set_image_id(self,image_id):
        self.__image_id = image_id